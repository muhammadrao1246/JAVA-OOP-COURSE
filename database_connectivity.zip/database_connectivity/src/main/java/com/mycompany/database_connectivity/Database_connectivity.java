/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.database_connectivity;
import java.sql.*;
import javax.swing.JOptionPane;
/**
 *
 * @author Home
 */
public class Database_connectivity {

    public static void main(String[] args) 
    {
        try{
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            String url = "jdbc:sqlserver://localhost:1433;databaseName=student";
            Connection con  = DriverManager.getConnection(url, "sa", "12345678");
            
            
            
            //if the connection is successful
            JOptionPane.showMessageDialog(null, "Connection Established");
            
            //inserting a ROW
            Statement stmt = con.createStatement();
            stmt.executeUpdate("insert into students values('2-ADAS-532','NOORULLAH')");
            
            JOptionPane.showMessageDialog(null, "Query Successful");
        }
        catch(Exception e)
        {
            System.out.println(e.toString());
        }
        
    }
}
